import { JSDOM } from 'jsdom';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { url } = req.body;
  
  if (!url) {
    return res.status(400).json({ error: 'URL is required' });
  }

  try {
    const response = await fetch(url);
    const html = await response.text();
    const dom = new JSDOM(html);
    const document = dom.window.document;
    
    // Extract property data (customize based on site)
    const propertyData = {
      price: extractPrice(document),
      bedrooms: extractBedrooms(document),
      bathrooms: extractBathrooms(document),
      sqft: extractSqft(document),
      features: extractFeatures(document),
      address: extractAddress(document),
      propertyType: extractPropertyType(document),
      description: extractDescription(document)
    };
    
    res.status(200).json({ success: true, data: propertyData });
  } catch (error) {
    console.error('Scraping error:', error);
    res.status(500).json({ error: 'Failed to scrape URL' });
  }
}

function extractPrice(doc) {
  const selectors = [
    '.price-display',
    '[data-testid="price"]',
    '.PropertyPrice',
    '.listing-price',
    '.price',
    '[class*="price"]',
    '[class*="Price"]'
  ];
  
  for (const selector of selectors) {
    const element = doc.querySelector(selector);
    if (element) {
      const text = element.textContent.trim();
      const price = text.replace(/[^\d]/g, '');
      if (price.length > 3) return parseInt(price);
    }
  }
  return null;
}

function extractBedrooms(doc) {
  const selectors = [
    '[data-testid="bedrooms"]',
    '.bedrooms',
    '[class*="bedroom"]',
    '[class*="Bedroom"]'
  ];
  
  for (const selector of selectors) {
    const element = doc.querySelector(selector);
    if (element) {
      const text = element.textContent.trim();
      const bedrooms = text.match(/\d+/);
      if (bedrooms) return parseInt(bedrooms[0]);
    }
  }
  return null;
}

function extractBathrooms(doc) {
  const selectors = [
    '[data-testid="bathrooms"]',
    '.bathrooms',
    '[class*="bathroom"]',
    '[class*="Bathroom"]'
  ];
  
  for (const selector of selectors) {
    const element = doc.querySelector(selector);
    if (element) {
      const text = element.textContent.trim();
      const bathrooms = text.match(/\d+(?:\.\d+)?/);
      if (bathrooms) return parseFloat(bathrooms[0]);
    }
  }
  return null;
}

function extractSqft(doc) {
  const selectors = [
    '[data-testid="sqft"]',
    '.sqft',
    '[class*="square"]',
    '[class*="Square"]'
  ];
  
  for (const selector of selectors) {
    const element = doc.querySelector(selector);
    if (element) {
      const text = element.textContent.trim();
      const sqft = text.replace(/[^\d]/g, '');
      if (sqft.length > 2) return parseInt(sqft);
    }
  }
  return null;
}

function extractFeatures(doc) {
  const selectors = [
    '.features',
    '.amenities',
    '[class*="feature"]',
    '[class*="amenity"]'
  ];
  
  for (const selector of selectors) {
    const element = doc.querySelector(selector);
    if (element) {
      const features = Array.from(element.querySelectorAll('li, .feature-item'))
        .map(item => item.textContent.trim())
        .filter(text => text.length > 0);
      
      if (features.length > 0) {
        return features.join(', ');
      }
    }
  }
  return null;
}

function extractAddress(doc) {
  const selectors = [
    '[data-testid="address"]',
    '.address',
    '[class*="address"]',
    '[class*="Address"]',
    'h1',
    '.property-title'
  ];
  
  for (const selector of selectors) {
    const element = doc.querySelector(selector);
    if (element) {
      const text = element.textContent.trim();
      if (text.includes(',') && text.length > 10) {
        return text;
      }
    }
  }
  return null;
}

function extractPropertyType(doc) {
  const selectors = [
    '.property-type',
    '[class*="type"]',
    '[class*="Type"]'
  ];
  
  for (const selector of selectors) {
    const element = doc.querySelector(selector);
    if (element) {
      const text = element.textContent.trim().toLowerCase();
      if (text.includes('single') || text.includes('family')) return 'single-family';
      if (text.includes('condo') || text.includes('apartment')) return 'condo';
      if (text.includes('townhouse')) return 'townhouse';
      if (text.includes('multi')) return 'multi-family';
      if (text.includes('land')) return 'land';
    }
  }
  return 'residential';
}

function extractDescription(doc) {
  const selectors = [
    '.description',
    '.property-description',
    '[class*="description"]',
    '[class*="Description"]'
  ];
  
  for (const selector of selectors) {
    const element = doc.querySelector(selector);
    if (element) {
      const text = element.textContent.trim();
      if (text.length > 50) {
        return text.substring(0, 500) + (text.length > 500 ? '...' : '');
      }
    }
  }
  return null;
}
